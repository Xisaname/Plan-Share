/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright 2022 NXP
 */

#ifndef KERNEL_MISC_ARCH_H
#define KERNEL_MISC_ARCH_H

#endif /*KERNEL_MISC_ARCH_H*/
